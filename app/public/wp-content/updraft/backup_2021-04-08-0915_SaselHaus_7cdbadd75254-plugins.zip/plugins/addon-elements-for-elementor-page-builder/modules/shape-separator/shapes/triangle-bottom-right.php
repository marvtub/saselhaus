<svg xmlns="http://www.w3.org/2000/svg" version="1.1" fill="<?php echo $settings['shape_color']; ?>" width="100%" height="90" viewBox="0 0 50 50" preserveAspectRatio="none" style="height: <?php echo $settings['shape_height']; ?>px;">
	<polygon class="fil0" points="0,50 50,50 50,0"></polygon>
</svg>
