<svg xmlns="http://www.w3.org/2000/svg" version="1.1" fill="<?php echo $settings['shape_color']; ?>" width="100%" height="90" viewBox="0 0 50 50" stroke="<?php echo $settings['shape_color']; ?>" stroke-width="1" preserveAspectRatio="none" style="height: <?php echo $settings['shape_height']; ?>px;">
	<polygon points="0,0 0,50 50,50"></polygon>
</svg>
