
jQuery(document).ready(function(){

    let cards =  document.getElementsByClassName("listing-col-border");

 

    cards[1].firstElementChild.style.borderColor = "#005FA8";
    cards[1].classList.add("blue-bg-hover")
    cards[2].firstElementChild.style.borderColor = "#B9CE00";
    cards[2].classList.add("yellow-bg-hover")
});

////////////////////////


jQuery(document).ready(function(){
   let card1 =  jQuery(".listing-col-border")[1]
   
   card.hover(function(){
        jQuery(this).css("background-color", "yellow");
      }, function(){
        jQuery(this).css("background-color", "pink");
    });


  });










  cards[1].addEventListener("mouseenter", function(){
    cards[1].style.backgroundColor = "#005FA8"
})
cards[1].addEventListener("mouseleave", function(){
    cards[1].style.backgroundColor = "transparent"
})
cards[2].addEventListener("mouseenter", function(){
    cards[2].style.backgroundColor = "#B9CE00"
})